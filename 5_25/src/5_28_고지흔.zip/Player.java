public interface Player {
    void setSpeed(double speed);
    void setTools(String[] tools);
    String getName();
    void showDetails();
}
